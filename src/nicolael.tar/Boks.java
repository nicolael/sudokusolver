
public class Boks extends Losning{
	int boksnr;
	
	Boks(int dimensjon, Brett brett){
		super(dimensjon, brett);
	}
	
	public void settBoksNr(int boksnr){
		this.boksnr = boksnr;
	}
	
	public int giBoksNr(){
		return boksnr;
	}
}
