
public class ForhaandsUtfyltRute extends Rute {

	ForhaandsUtfyltRute(Brett b) {
		super(b);

	}

}
