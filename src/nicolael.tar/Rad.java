
public class Rad extends Losning{
	int plass;
	Rad(int dimensjon, Brett brett){
		super(dimensjon, brett);
	}
}
