import java.util.ArrayList;

public class Losning {
	Rute[]ruter;
	Brett brett;
	int dimensjon;
	Rute neste;
	Rute rute;
	Rad rad;

	int cnt = 0;

	Losning(int dimensjon, Brett brett){
		this.dimensjon = dimensjon;
		this.brett = brett;
		ruter = new Rute[dimensjon];
	}


	public boolean lovlig(int tall){
	

		for(Rute rute : ruter ){

			if(rute.tall == tall){

				return false;
			}
		}
		return true;
	}

	public void printRuter() {
	
		for(int i=0; i< ruter.length; i++) {
			System.out.print(ruter[i] + " ");
		}

		System.out.println();
	}

	public void add(Rute r){
		ruter[cnt++] = r;
	}
}
