import java.io.*;
import java.util.Scanner;

public class Rute {
	int tall;
	Kolonne kolonne;
	Rad rad;
	Boks boks;
	Rute neste;
	Brett brett;

	Rute(Brett brett){
		this.brett = brett;
	}

	public String toString (){

		return Integer.toString(tall);
	}

	public void settTallMegOgResten(){

		if(this instanceof ForhaandsUtfyltRute )
			if(neste != null){
				neste.settTallMegOgResten();
			}else{
				brett.lagreBuffer();
			}
		else{
			for(int i = 1; i <= brett.dimensjon; i++){

				if(boks.lovlig(i) && rad.lovlig(i) && kolonne.lovlig(i)){

					tall=i;

					if (neste == null){

						brett.lagreBuffer();

					}
					else neste.settTallMegOgResten();

				}
				tall = 0;
			}

		}
	}
}