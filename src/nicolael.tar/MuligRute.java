
public class MuligRute extends Rute{
	MuligRute(Brett b) {
		super(b);
	}
	boolean kanEndres = false;
	int verdi;


}
