
public class Kolonne extends Losning{
	int plass;

	Kolonne(int dimensjon, Brett brett){
		super(dimensjon, brett);
	}

}
