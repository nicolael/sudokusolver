import java.util.ArrayList;

public class SudukoBuffer {
	int current = 0;
	int teller = 0;
	int counter = 0;
	int [][]bufferLosning = new int[500][];

	public void settInn(int[] losning){

		if(teller < 500){

			bufferLosning[teller] = losning;

		}
		teller++;

	}
	public int [] get(){
	
			return bufferLosning[current++];
	
	}
	public int hentAntallLosninger(){

		return teller;
	}
}
